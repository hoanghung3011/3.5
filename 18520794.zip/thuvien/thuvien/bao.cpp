#include "bao.h"



bao::bao()
{
}

void bao::input()
{
	tailieu::input();
	date::input();
}

void bao::output()
{
	tailieu::output();
	date::output();
}
bao::~bao()
{
}
