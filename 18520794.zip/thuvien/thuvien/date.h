#pragma once
#include "tailieu.h"
class date
{
protected:
	int ngay;
	int thang;
	int nam;
public:
	date();
	void input();
	void output();
	~date();
};

