#pragma once
#include "tailieu.h"
class tapchi :public tailieu
{
private:
	int soph;
	int thangph;
public:
	tapchi();
	void input();
	void output();
	~tapchi();
};

