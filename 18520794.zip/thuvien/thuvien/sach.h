#pragma once
#include "tailieu.h"
class sach :public tailieu
{
private:
	int trang;
	char tacgia[20];
public:
	sach();
	void input();
	void output();
	~sach();
};

